<ul class="custom-pager custom-pager-<?php print $position; ?>">
  <li class="first"><?php print $first; ?></li>
  <li class="previous"><?php print $previous; ?></li>
  <li class="key"><?php print $key; ?></li>
  <li class="next"><?php print $next; ?></li>
  <li class="last"><?php print $last; ?></li>
</ul>